from PIL import Image
# import an image
image = Image.open(r'Assets\Insects\1_Limniu 2021_1_2021_06_02-13-08-37-981.PNG')
# flip
# image_transpose = image.transpose(Image.Transpose.ROTATE_90)
# rotation
# image_rotate = image.rotate(45, expand = False, center = (0,0))
# crop
# w, h = image.size

# image_crop = image.crop((w//4, h//4, 3*w//4, 3*h//4))
# resize
image_resize = image.resize((400,300))
# applying multiple transformations to an image in a single line of
#code
# combined_image = image.transpose(Image.Transpose.ROTATE_90).resize((2000,1500)).rotate(10)
# combined_image.show()
# image_crop.show()
image_resize.show()