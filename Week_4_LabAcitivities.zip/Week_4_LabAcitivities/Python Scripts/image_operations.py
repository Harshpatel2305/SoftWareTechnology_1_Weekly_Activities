# image_operations.py
from PIL import Image, ImageOps
import os

# create an image
image = Image.open(r'Assets\Insects\2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG')

# position changes
image_mirror = ImageOps.mirror(image)

# color changes
image_inverted = ImageOps.invert(image_mirror)

# add and remove
image_border = ImageOps.expand(
    image=image_inverted,
    border=50,
    fill=(255, 255, 255))
image_border.show()
image_inverted.show()
image_mirror.show()

image_border.save('image_border.png', 'PNG')
image_inverted.save('image_inverted.png','PNG')
image_mirror.save('image_mirror.png','PNG')

