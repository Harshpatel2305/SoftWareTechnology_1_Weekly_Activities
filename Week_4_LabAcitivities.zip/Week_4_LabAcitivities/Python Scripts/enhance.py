# enhance.py
from PIL import Image, ImageEnhance

# import an image
image = Image.open(r'Assets\Insects\2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG')

# create an enhancer
vibrance_enhancer = ImageEnhance.Color(image)
contrast_enhancer = ImageEnhance.Contrast(image)
brightness_enhancer = ImageEnhance.Brightness(image)
sharpness_enhancer = ImageEnhance.Sharpness(image)

# apply the enhancers
enhanced_vibrance = vibrance_enhancer.enhance(5)
enhanced_contrast = contrast_enhancer.enhance(5)

# show
enhanced_vibrance.save('enhanced_vibrance.png', 'PNG')
enhanced_vibrance.show()
enhanced_contrast.save('enhanced_contrast.png', 'PNG')
enhanced_contrast.show()
