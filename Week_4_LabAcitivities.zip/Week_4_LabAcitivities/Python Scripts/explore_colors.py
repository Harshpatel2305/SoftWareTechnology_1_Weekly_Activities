# explore_colors.py
from PIL import Image

image = Image.open('Assets/Insects/1_Gammar 2021_1_2021_06_03-13-19-23-879.PNG').convert('RGB')

# get one pixel
print("Pixel at (0,0):", image.getpixel((0, 0)))

# grayscale channel images
red_grayscale_image = image.getchannel('R')
blue_grayscale_image = image.getchannel('B')

red_grayscale_image.save('red_channel.png', 'PNG')
red_grayscale_image.show()
blue_grayscale_image.save('blue_channel.png', 'PNG')
blue_grayscale_image.show()


# change a pixel color
image.putpixel((0, 0), (255, 0, 255))

# replace all pixels where red channel == 0 with a dark red color
width,height = image.size
count:int = 0
for x in range(width):
    for y in range(height):
        if image.getpixel((x, y))[0] == 0:
            image.putpixel((x, y), (200, 20, 20))
            count += 1

print(f"Pixels replaced: {count}")

image.save('pixel_replaced.png', 'PNG')
image.show()